import os

class TranslatorConfig:
    TRANSLATOR_KEY = "d07c486a86e04ccf90651d02c1b49ac1"
    # Endpoint for text
    TRANSLATOR_ENDPOINT = "https://api.cognitive.microsofttranslator.com"
    TRANSLATOR_LOCATION = "westeurope"
    TRANSLATE_PATH = "/translate"
    TRANSLATE_CONSTRUCTED_URL = TRANSLATOR_ENDPOINT + TRANSLATE_PATH